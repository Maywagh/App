import 'dart:ffi';

import 'package:flutter/material.dart';

class Home extends StatelessWidget {
  const Home({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading: IconButton(
          icon: Icon(Icons.menu),
          onPressed: () {},
        ),
        title: Text('Home'),
        actions: [
          IconButton(
            icon: Icon(Icons.shopping_cart),
            onPressed: () {},
          ),
          IconButton(
            icon: Icon(Icons.search),
            onPressed: () {},
          ),
        ],
        elevation: 10,
        backgroundColor: Colors.grey,
        body: Center(
          child: ElevatedButton(
            child: Text('Beers'),
            onPressed: () {},
            style: ElevatedButton.styleFrom(padding: EdgeInsets.all(20.0)),
          ),
        ),
      ),
    );
  }
}
